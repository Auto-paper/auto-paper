This folder will contain scripts for QR Generation and Decoding.
